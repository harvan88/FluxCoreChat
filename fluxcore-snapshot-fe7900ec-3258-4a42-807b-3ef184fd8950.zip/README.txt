Snapshot export for account f72fc07f-b401-4377-964d-d2b51fabdff1.
Incluye datos de conversaciones, mensajes, configuraciones y automatizaciones activas.
